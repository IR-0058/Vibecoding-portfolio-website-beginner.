window.PORTFOLIO_DATA={
  profile:{name:'Ilham Ramadhani',role:'Informatics · Creative Technology',location:'Surabaya, Indonesia',bio:'Mencatat perjalanan, karya, dan cara berpikir dalam satu ruang digital yang terus bertumbuh.',profileImage:'assets/images/profile/profile.svg'},
  stats:{yearsActive:1},
  skills:['HTML5','CSS3','JavaScript','UI/UX','Database','Creative Coding'],
  photos:Array.from({length:60},(_,i)=>({id:i+1,title:`Selected Moment ${String(i+1).padStart(2,'0')}`,src:`assets/images/photos/photo-${String(i+1).padStart(2,'0')}.jpg`,caption:'Slot lokal — isi dengan foto milik sendiri.',category:i%3===0?'Journey':i%3===1?'Study':'Creative'})),
  videos:Array.from({length:60},(_,i)=>({id:i+1,title:`Selected Work ${String(i+1).padStart(2,'0')}`,src:`assets/videos/video-${String(i+1).padStart(2,'0')}.mp4`,poster:`assets/images/thumbnails/video-${String(i+1).padStart(2,'0')}.jpg`,category:i%3===0?'Journey':i%3===1?'Project':'Creative'}))
};
