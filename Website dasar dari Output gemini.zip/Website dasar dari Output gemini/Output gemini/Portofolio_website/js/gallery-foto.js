/**
 * PHOTO GALLERY LOGIC & LIGHTBOX
 */

document.addEventListener("DOMContentLoaded", () => {
    if (typeof PORTFOLIO_DATA === 'undefined') return;

    const photos = PORTFOLIO_DATA.photos;
    const categories = PORTFOLIO_DATA.categories;
    
    const grid = document.getElementById("photo-grid");
    const filterBar = document.getElementById("photo-category-bar");

    // Modal elements
    const lightbox = document.getElementById("photo-lightbox");
    const imgEl = document.getElementById("lightbox-img");
    const titleEl = document.getElementById("lightbox-title");
    const descEl = document.getElementById("lightbox-desc");
    const closeBtn = document.getElementById("modal-close");
    const prevBtn = document.getElementById("lightbox-prev");
    const nextBtn = document.getElementById("lightbox-next");

    let currentPhotoIndex = 0;
    let filteredPhotos = [...photos];

    // Render Filters
    function renderFilters() {
        if (!filterBar) return;
        filterBar.innerHTML = "";
        categories.forEach((cat, idx) => {
            const btn = document.createElement("button");
            btn.className = `filter-btn ${idx === 0 ? 'active' : ''}`;
            btn.textContent = cat;
            btn.addEventListener("click", () => {
                document.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("active"));
                btn.classList.add("active");
                filterPhotos(cat);
            });
            filterBar.appendChild(btn);
        });
    }

    function filterPhotos(cat) {
        if (cat === "All") {
            filteredPhotos = [...photos];
        } else {
            filteredPhotos = photos.filter(p => p.category === cat);
        }
        renderGrid();
    }

    // Render Grid Cards
    function renderGrid() {
        if (!grid) return;
        grid.innerHTML = "";
        filteredPhotos.forEach((item, index) => {
            const card = document.createElement("div");
            card.className = "gallery-card";
            card.innerHTML = `
                <div class="gallery-thumb-wrapper">
                    <!-- SVG Fallback Frame if local photo isn't replaced yet -->
                    <svg width="100%" height="100%" viewBox="0 0 300 375" style="background:#112240;">
                        <rect width="100%" height="100%" fill="#112240"/>
                        <text x="50%" y="45%" dominant-baseline="middle" text-anchor="middle" fill="#64FFDA" font-size="16" font-family="sans-serif">
                            PHOTO SLOT #${item.id.replace('photo-', '')}
                        </text>
                        <text x="50%" y="55%" dominant-baseline="middle" text-anchor="middle" fill="#8892B0" font-size="12" font-family="sans-serif">
                            ${item.category}
                        </text>
                    </svg>
                </div>
                <div class="card-meta">
                    <span class="card-category">${item.category}</span>
                    <h4 class="card-title">${item.title}</h4>
                    <span class="card-date">${item.date}</span>
                </div>
            `;
            card.addEventListener("click", () => openLightbox(index));
            grid.appendChild(card);
        });
    }

    function openLightbox(index) {
        currentPhotoIndex = index;
        updateLightbox();
        lightbox.classList.add("active");
    }

    function updateLightbox() {
        const item = filteredPhotos[currentPhotoIndex];
        if (!item) return;
        
        // Generate dynamic fallback SVG for modal preview
        imgEl.src = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600"><rect width="100%" height="100%" fill="%23112240"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="%2364FFDA" font-size="28" font-family="sans-serif">${item.title}</text></svg>`;
        titleEl.textContent = item.title;
        descEl.textContent = item.description;
    }

    closeBtn?.addEventListener("click", () => lightbox.classList.remove("active"));
    prevBtn?.addEventListener("click", () => {
        currentPhotoIndex = (currentPhotoIndex - 1 + filteredPhotos.length) % filteredPhotos.length;
        updateLightbox();
    });
    nextBtn?.addEventListener("click", () => {
        currentPhotoIndex = (currentPhotoIndex + 1) % filteredPhotos.length;
        updateLightbox();
    });

    renderFilters();
    renderGrid();
});
