/**
 * MAIN INTERACTIVE ENGINE & LOBBY LOGIC
 */

document.addEventListener("DOMContentLoaded", () => {
    // 1. Real-time Local Clock
    function initClock() {
        const clockEl = document.getElementById("clock-time");
        if (!clockEl) return;
        
        function updateTime() {
            const now = new Date();
            const hrs = String(now.getHours()).padStart(2, '0');
            const mins = String(now.getMinutes()).padStart(2, '0');
            const secs = String(now.getSeconds()).padStart(2, '0');
            clockEl.textContent = `${hrs}:${mins}:${secs}`;
        }
        updateTime();
        setInterval(updateTime, 1000);
    }

    // 2. Dynamic Calendar Generator
    function initCalendar() {
        const daysGrid = document.getElementById("calendar-days-grid");
        if (!daysGrid) return;

        const now = new Date();
        const today = now.getDate();
        const totalDays = 31; // October standard

        daysGrid.innerHTML = "";
        const dayLabels = ["S", "M", "T", "W", "T", "F", "S"];
        dayLabels.forEach(d => {
            const span = document.createElement("span");
            span.style.fontWeight = "bold";
            span.textContent = d;
            daysGrid.appendChild(span);
        });

        for (let i = 1; i <= totalDays; i++) {
            const span = document.createElement("span");
            span.textContent = i;
            if (i === today) span.className = "today";
            daysGrid.appendChild(span);
        }
    }

    // 3. Render 16-Slice Pizza Wheel Diagram
    function initPizzaWheel() {
        const wheel = document.getElementById("pizza-wheel");
        if (!wheel) return;

        const slices = 16;
        const angle = 360 / slices;

        for (let i = 0; i < slices; i++) {
            const slice = document.createElement("div");
            slice.className = "wheel-slice";
            const rotation = i * angle;
            slice.style.transform = `rotate(${rotation}deg) skewY(-${90 - angle}deg)`;

            const numSpan = document.createElement("span");
            numSpan.className = "slice-number";
            numSpan.textContent = String(i + 1).padStart(2, '0');
            slice.appendChild(numSpan);

            slice.addEventListener("click", () => {
                alert(`Slice ${i + 1} terpilih! Membuka pratinjau kategori ke-${i + 1}.`);
            });

            wheel.appendChild(slice);
        }
    }

    // 4. Mouse 3D Tilt & Aurora Glow Parallax
    function init3DTilt() {
        const tiltCards = document.querySelectorAll(".3d-tilt");
        const aurora = document.getElementById("aurora-bg");

        document.addEventListener("mousemove", (e) => {
            const x = (e.clientX / window.innerWidth) - 0.5;
            const y = (e.clientY / window.innerHeight) - 0.5;

            if (aurora) {
                aurora.style.transform = `translate(${x * 40}px, ${y * 40}px)`;
            }

            tiltCards.forEach(card => {
                const rect = card.getBoundingClientRect();
                if (e.clientX > rect.left - 50 && e.clientX < rect.right + 50 &&
                    e.clientY > rect.top - 50 && e.clientY < rect.bottom + 50) {
                    const tiltX = -y * 12;
                    const tiltY = x * 12;
                    card.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) scale3d(1.02, 1.02, 1.02)`;
                } else {
                    card.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`;
                }
            });
        });
    }

    // 5. Populate Profile & Dashboard Stats from portfolio-data.js
    function initDashboard() {
        if (typeof PORTFOLIO_DATA === 'undefined') return;

        const data = PORTFOLIO_DATA;
        
        // Profile
        const nameEl = document.getElementById("profile-name");
        const titleEl = document.getElementById("profile-title");
        if (nameEl) nameEl.textContent = data.profile.name;
        if (titleEl) titleEl.textContent = data.profile.title;

        // Stats
        const statPhotos = document.getElementById("stat-photos");
        const statVideos = document.getElementById("stat-videos");
        const statArt = document.getElementById("stat-art");
        const statTech = document.getElementById("stat-tech");

        if (statPhotos) statPhotos.textContent = data.stats.totalPhotos;
        if (statVideos) statVideos.textContent = data.stats.totalVideos;
        if (statArt) statArt.textContent = `${data.stats.artScore}%`;
        if (statTech) statTech.textContent = `${data.stats.techScore}%`;
    }

    // 6. Scroll-Driven Entrance Observer
    function initScrollEntrance() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("visible");
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll(".scroll-entrance").forEach(el => observer.observe(el));
    }

    // Initialize all modules
    initClock();
    initCalendar();
    initPizzaWheel();
    init3DTilt();
    initDashboard();
    initScrollEntrance();
});
