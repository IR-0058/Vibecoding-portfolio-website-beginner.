/**
 * VIDEO GALLERY LOGIC & PLAYER MODAL
 */

document.addEventListener("DOMContentLoaded", () => {
    if (typeof PORTFOLIO_DATA === 'undefined') return;

    const videos = PORTFOLIO_DATA.videos;
    const categories = PORTFOLIO_DATA.categories;
    
    const grid = document.getElementById("video-grid");
    const filterBar = document.getElementById("video-category-bar");

    const vmodal = document.getElementById("video-modal");
    const player = document.getElementById("vmodal-player");
    const titleEl = document.getElementById("vmodal-title");
    const descEl = document.getElementById("vmodal-desc");
    const closeBtn = document.getElementById("vmodal-close");

    let filteredVideos = [...videos];

    function renderFilters() {
        if (!filterBar) return;
        filterBar.innerHTML = "";
        categories.forEach((cat, idx) => {
            const btn = document.createElement("button");
            btn.className = `filter-btn ${idx === 0 ? 'active' : ''}`;
            btn.textContent = cat;
            btn.addEventListener("click", () => {
                document.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("active"));
                btn.classList.add("active");
                filterVideos(cat);
            });
            filterBar.appendChild(btn);
        });
    }

    function filterVideos(cat) {
        if (cat === "All") {
            filteredVideos = [...videos];
        } else {
            filteredVideos = videos.filter(v => v.category === cat);
        }
        renderGrid();
    }

    function renderGrid() {
        if (!grid) return;
        grid.innerHTML = "";
        filteredVideos.forEach((item, index) => {
            const card = document.createElement("div");
            card.className = "gallery-card";
            card.innerHTML = `
                <div class="gallery-thumb-wrapper">
                    <svg width="100%" height="100%" viewBox="0 0 300 375" style="background:#0A192F;">
                        <rect width="100%" height="100%" fill="#0A192F"/>
                        <circle cx="50%" cy="45%" r="30" fill="#112240" stroke="#64FFDA" stroke-width="2"/>
                        <polygon points="145,160 165,170 145,180" fill="#64FFDA"/>
                        <text x="50%" y="65%" dominant-baseline="middle" text-anchor="middle" fill="#8892B0" font-size="12" font-family="sans-serif">
                            REEL #${item.id.replace('video-', '')} (${item.duration})
                        </text>
                    </svg>
                </div>
                <div class="card-meta">
                    <span class="card-category">${item.category}</span>
                    <h4 class="card-title">${item.title}</h4>
                    <span class="card-date">Durasi: ${item.duration}</span>
                </div>
            `;
            card.addEventListener("click", () => openVideoModal(item));
            grid.appendChild(card);
        });
    }

    function openVideoModal(item) {
        titleEl.textContent = item.title;
        descEl.textContent = item.description;
        vmodal.classList.add("active");
    }

    closeBtn?.addEventListener("click", () => {
        vmodal.classList.remove("active");
        player.pause();
    });

    renderFilters();
    renderGrid();
});
