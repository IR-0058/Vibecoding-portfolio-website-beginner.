/**
 * Centralized Portfolio Data
 * Art × Culture × Technology
 * Supporting 50+ Photo slots and 50+ Video slots
 */

const PORTFOLIO_DATA = {
    profile: {
        name: "ir_",
        title: "Creative Developer & Visual Architect",
        bio: "Mencatat perjalanan hidup, pengembangan nilai diri, dan eksplorasi filosofi Seni × Budaya × Teknologi.",
        location: "Surabaya, Indonesia",
        buildVersion: "v1.0 (2026)",
        philosophy: "Melestarikan Seni & Budaya melalui Algoritma Modern secara Offline-First."
    },
    stats: {
        totalPhotos: 52,
        totalVideos: 50,
        artScore: 94,
        cultureScore: 88,
        techScore: 96,
        milestonesCount: 18
    },
    categories: ["All", "Art & Design", "Culture & Heritage", "Tech & Innovation", "Personal Journey"],
    
    // Generate 52 Photo Items dynamically
    photos: Array.from({ length: 52 }, (_, i) => {
        const id = i + 1;
        const categories = ["Art & Design", "Culture & Heritage", "Tech & Innovation", "Personal Journey"];
        const cat = categories[i % categories.length];
        return {
            id: `photo-${id}`,
            title: `Moment #${id} - ${cat}`,
            category: cat,
            date: `2026-0${(i % 9) + 1}-15`,
            src: `assets/images/photos/photo_${id}.jpg`,
            thumbnail: `assets/images/thumbnails/thumb_photo_${id}.jpg`,
            description: `Dokumentasi perjalanan hidup dan eksplorasi visual ke-${id} yang merefleksikan nilai ${cat.toLowerCase()}.`,
            tags: [cat.split(' ')[0].toLowerCase(), "portfolio", "life-log"]
        };
    }),

    // Generate 50 Video Items dynamically
    videos: Array.from({ length: 50 }, (_, i) => {
        const id = i + 1;
        const categories = ["Tech & Innovation", "Art & Design", "Culture & Heritage", "Personal Journey"];
        const cat = categories[i % categories.length];
        return {
            id: `video-${id}`,
            title: `Cinematic Reel #${id} - ${cat}`,
            category: cat,
            date: `2026-0${(i % 9) + 1}-20`,
            src: `assets/videos/video_${id}.mp4`,
            poster: `assets/images/thumbnails/poster_video_${id}.jpg`,
            duration: `0${(i % 3) + 1}:${(i * 7) % 60 < 10 ? '0' : ''}${(i * 7) % 60}`,
            description: `Rekaman video karya interaktif & pergerakan ide ke-${id} dalam format reels sinematik.`,
            tags: [cat.split(' ')[0].toLowerCase(), "cinema", "video-log"]
        };
    }),

    timeline: [
        { year: "2024", event: "Inisiasi Vibe Coding & Arsitektur Portofolio Personal" },
        { year: "2025", event: "Eksplorasi Algoritma Batik Parametrik & Visual Engine" },
        { year: "2026", event: "Peluncuran Platform Portofolio Offline-First (Art × Culture × Tech)" }
    ]
};

if (typeof module !== 'undefined') {
    module.exports = PORTFOLIO_DATA;
}
