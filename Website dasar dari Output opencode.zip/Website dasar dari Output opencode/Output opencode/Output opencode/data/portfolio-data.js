/* ==========================================================================
   PORTFOLIO DATA - SATU-SATUNYA SUMBER DATA
   --------------------------------------------------------------------------
   File ini adalah "otak" website. Semua halaman membacanya dari sini.
   Kamu cukup MENGUBAH file ini, tidak perlu menyentuh HTML/CSS/JS lain.

   CARA PAKAI SINGKAT:
   1) Foto  -> taruh file .jpg/.png/.webp di  assets/images/photos/
               lalu isi property `src` pada item (path relatif dari root folder).
   2) Video -> taruh file .mp4/.webm di    assets/videos/
               lalu isi property `src` pada item.
   3) Slot kosong otomatis jadi frame placeholder (tidak error).
   ========================================================================== */

window.PORTFOLIO_DATA = {

  /* ---------------------------------------------------------------- BRAND */
  brand: {
    mark: 'IR',
    name: 'ir_',
    tagline: 'Art x Culture x Technology',
    short: 'Portofolio Perjalanan & Karya'
  },

  /* -------------------------------------------------------------- PROFIL */
  profile: {
    name: 'ir_',
    fullName: 'ir_',
    role: 'Vibe Coder, Seniman Visual, Penulis',
    location: 'Surabaya, Jawa Timur, Indonesia',
    timezone: 'Asia/Jakarta',
    timezoneLabel: 'WIB',
    since: '2019-04-21',

    // Foto utama HERO. Tidak diberi frame/background apa pun.
    heroPhoto: 'assets/images/profile/profil.jpg',

    lead: 'Art x Culture x Technology',
    body: [
      'Saya menulis perjalanan hidup ini sebagai karya, bukan sebagai laporan. Setiap foto dan video di bawah adalah jejak, bukan pamer, tapi arsip.',
      'Kebiasaan saya: berpikir pelan dulu, baru merender. Library lokal, tanpa cloud, tanpa langganan. Semua yang kamu lihat di sini benar-benar ada di perangkatmu.'
    ],

    // Baris detail kecil di bawah bio (dipisah |)
    facts: [
      'Basis: Surabaya',
      'Fokus: Web Statis & Visual',
      'Mode: Offline-First'
    ],

    quote: '"Yang tidak tercatat akan hilang. Yang tercatat dengan buruk akan disalahartikan."'
  },

  /* --------------------------------------------------------------- STATS */
  stats: {
    projects: 48,
    releases: 12,
    hoursLogged: 3170,
    mediaCapacity: 50
  },

  /* --------------------------------------------------------------- FOTO
     total = jumlah slot yang dirender (placeholder ikut dihitung)
     items = daftar yang sudah diisi. Kosongkan `src` untuk testing placeholder.
  */
  photos: {
    total: 60,
    items: [
      {
        src: '',
        title: 'Pagi di River City',
        caption: 'Menyusuri sungai sebelum pasar bangun. Kota ini belum jadi apa-apa.',
        tags: ['perjalanan', 'lanskap'],
        date: '2026-08-14',
        place: 'Surabaya',
        featured: true
      },
      {
        src: '',
        title: 'Sketsa Wajah 01',
        caption: 'Studi dari hidup. Garis pertama selalu paling jujur.',
        tags: ['wajah', 'karya'],
        date: '2026-07-02',
        place: 'Studio Rumah',
        featured: true
      },
      {
        src: '',
        title: 'Fraktal Batik',
        caption: 'Motif parametric yang dibangkitkan dari angka, lalu dijahit manual.',
        tags: ['karya', 'budaya'],
        date: '2026-05-21',
        place: 'Studio Rumah',
        featured: true
      },
      {
        src: '',
        title: 'Jalan Pulang',
        caption: 'Rekaman kabut di jalan pulang. Tidak ada yang spesial, dan itu bagus.',
        tags: ['perjalanan', 'lanskap'],
        date: '2026-04-09',
        place: 'Malang',
        featured: false
      },
      {
        src: '',
        title: 'Rak Buku Tua',
        caption: 'Arsip file yang pernah hilang, ditemukan lagi setelah empat tahun.',
        tags: ['arsip'],
        date: '2026-02-17',
        place: 'Rumah',
        featured: false
      },
      {
        src: '',
        title: 'Roda Gigi Lama',
        caption: 'Bekel manual yang masih hidup. Diremek dari mesin, lalu dibongkar satu per satu.',
        tags: ['teknologi', 'karya'],
        date: '2025-12-30',
        place: 'Bengkel Solo',
        featured: false
      }
    ]
  },

  /* --------------------------------------------------------------- VIDEO */
  videos: {
    total: 60,
    items: [
      {
        src: '',
        poster: '',
        title: 'Reel: Jalan Satu Aarah',
        caption: 'Potongan 47 detik. Potongan yang paling sering kubuka saat konsentrasi anjlok.',
        tags: ['perjalanan', 'reel'],
        date: '2026-09-01',
        place: 'Bali',
        duration: '00:47',
        featured: true
      },
      {
        src: '',
        poster: '',
        title: 'Behind The Grid',
        caption: 'Proses membangkitkan pola fraktal menjadi tekstur cetak.',
        tags: ['karya', 'teknologi'],
        date: '2026-06-18',
        place: 'Studio Rumah',
        duration: '02:14',
        featured: true
      },
      {
        src: '',
        poster: '',
        title: 'Ambient Session #3',
        caption: 'Rekaman latihan musik latar untuk proyek ini.',
        tags: ['musik', 'karya'],
        date: '2026-03-11',
        place: 'Kamar',
        duration: '05:02',
        featured: false
      }
    ]
  },

  /* -------------------------------------------------------------- SKILLS */
  skills: [
    { name: 'HTML5 & Semantic', level: 92, note: 'Struktur yang bisa dibaca mesin dan difabel' },
    { name: 'CSS3 / Design Token', level: 95, note: 'Sistem warna Navy x Putih, gradient dan glass' },
    { name: 'Vanilla JS', level: 88, note: 'Tanpa framework, tanpa dependensi' },
    { name: 'Seni Visual', level: 74, note: 'Komposisi, warna, framing' },
    { name: 'Budaya & Narasi', level: 70, note: 'Motif, simbol, cerita lokal' },
    { name: 'Dokumentasi', level: 81, note: 'PRD, README, prompt log' }
  ],

  /* ------------------------------------------------------------ TIMELINE */
  timeline: [
    {
      year: '2019',
      title: 'Titik Nol',
      text: 'Mulai menulis harian. Kamera dihemat, tidak dipakai. Itu kesalahan yang baik.',
      tag: 'awal'
    },
    {
      year: '2021',
      title: 'Fraktal & Batik',
      text: 'Bertemu pemetaan matematis. Mulai percaya algoritma bisa punya rasa.',
      tag: 'karya'
    },
    {
      year: '2023',
      title: 'Offline-First',
      text: 'Berhenti bergantung pada layanan pihak ketiga. Semua turun ke lokal.',
      tag: 'teknologi'
    },
    {
      year: '2026',
      title: 'Portofolio Jadi Sistem',
      text: 'Karya, perjalanan, dan catatan kaki disatukan dalam satu website.',
      tag: 'sekarang'
    }
  ],

  /* ------------------------------------------------------------- DIAGRAM
     Diagram interaktif Art x Culture x Technology.
     `x` dan `y` dalam persen (0-100) di dalam viewBox 100 x 60.
  */
  diagram: {
    caption: 'Tiga poros yang membentuk cara saya melihat dan membuat.',
    nodes: [
      {
        id: 'art',
        label: 'ART',
        sub: 'Seni Visual',
        x: 50,
        y: 12,
        note: 'Bentuk, warna, ritme. Menunda keputusan visual sampai terasa benar, bukan sampai terlihat ramai.'
      },
      {
        id: 'culture',
        label: 'CULTURE',
        sub: 'Budaya & Narasi',
        x: 10,
        y: 86,
        note: 'Motif batik, cerita lokal, dan simbol yang membawa makna lebih lama daripada teks.'
      },
      {
        id: 'technology',
        label: 'TECHNOLOGY',
        sub: 'Kode & Sistem',
        x: 90,
        y: 86,
        note: 'Vanilla JS, model data lokal, dan aturan yang masih bisa dibaca orang lain besok.'
      }
    ],
    ribbons: [
      { from: 'art', to: 'culture', weight: 3, label: 'motif' },
      { from: 'culture', to: 'technology', weight: 2, label: 'struktur' },
      { from: 'technology', to: 'art', weight: 4, label: 'render' }
    ]
  },

  /* ------------------------------------------------------------ KALENDER
     key = format "YYYY-MM-DD". value = catatan hari tersebut.
  */
  calendar: {
    notes: {
      '2019-04-21': 'Hari pertama menulis jurnal digital.',
      '2026-08-14': 'Fase pembaruan website.',
      '2026-10-07': 'Rilis v1.0.0 - semua folder media siap diisi.'
    }
  },

  /* -------------------------------------------------------------- SOSMED */
  social: [
    { label: 'GitHub', url: 'https://github.com/', handle: '@ir_' },
    { label: 'Instagram', url: 'https://instagram.com/', handle: '@ir_' },
    { label: 'Email', url: 'mailto:halo@example.com', handle: 'halo@example.com' },
    { label: 'CV', url: 'assets/documents/CV.pdf', handle: 'Unduh' }
  ],

  /* -------------------------------------------------------------- RELEASE */
  release: {
    version: 'v1.0.0',
    codename: 'Zero Website',
    build: '2026.10.07'
  },

  /* --------------------------------------------------------------- FOOTER */
  footer: {
    brandTitle: 'Melestarikan Seni & Budaya melalui Algoritma Modern.',
    brandText: 'Portofolio ini dibangun offline-first. Tidak ada server, tidak ada basis data, tidak ada pelacak. Semua isi berasal dari perangkat ini.',
    address: 'Surabaya, Jawa Timur, Indonesia',
    copyrightOwner: 'ir_'
  },

  /* ----------------------------------------------------------- SOUNDSCAPE
     Kosongkan `src` untuk memakai ambience sintesis (dibuat langsung oleh Web Audio).
     Isi `src` dengan file lokal, contoh: 'assets/audio/ambient.mp3'
  */
  soundscape: {
    src: '',
    title: 'Ambient Dock - ir_',
    subtitle: 'Lo-fi pad sintetis, tanpa file eksternal'
  },

  /* ------------------------------------------------------------ KURASI
     Item yang tampil di preview Lobby dan 16 slice pizza wheel.
  */
  curation: {
    photoPreview: 3,
    videoPreview: 3,
    wheelSlices: 16
  }
};
