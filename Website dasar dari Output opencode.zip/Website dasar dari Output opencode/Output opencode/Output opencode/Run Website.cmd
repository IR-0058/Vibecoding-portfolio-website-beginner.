@echo off
title ir_ Portfolio
cd /d "%~dp0"
set PORT=8730
echo.
echo   ir_ Portfolio Website
echo   --------------------------------------
echo.
where python >nul 2>nul
if %errorlevel%==0 goto :viaPython
where py >nul 2>nul
if %errorlevel%==0 goto :viaPy
echo   Python tidak ditemukan. Membuka file langsung.
start "" "%~dp0index.html"
echo.
pause
exit /b 0
:viaPython
echo   Menjalankan server lokal di http://localhost:%PORT%/
echo   Tutup jendela ini untuk menghentikan server.
echo.
start "" "http://localhost:%PORT%/index.html"
python -m http.server %PORT% --bind 127.0.0.1
exit /b 0
:viaPy
echo   Menjalankan server lokal di http://localhost:%PORT%/
echo   Tutup jendela ini untuk menghentikan server.
echo.
start "" "http://localhost:%PORT%/index.html"
py -m http.server %PORT% --bind 127.0.0.1
exit /b 0

