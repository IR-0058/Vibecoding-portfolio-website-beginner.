/* ==========================================================================
   gallery-video.js — LOGIC GALERI VIDEO
   Grid 60 slot, filter kategori, pencarian, custom player/modal.
   ATURAN: TIDAK BOLEH autoplay massal. Video hanya jalan saat diklik user.
   ========================================================================== */
(function () {
  'use strict';

  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  };
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  var grid = $('#grid');
  if (!grid) return;

  var all = (window.__MEDIA && window.__MEDIA.videos) || [];
  var active = 'semua';
  var query = '';

  /* ------------------------------------------------------------ STATS */
  function renderStats() {
    var filled = all.filter(function (x) { return x.filled; }).length;
    var tags = {};
    all.forEach(function (x) { (x.tags || []).forEach(function (t) { if (t !== 'kosong') tags[t] = 1; }); });
    var map = { statTotal: all.length, statFilled: filled, statEmpty: all.length - filled, statTags: Object.keys(tags).length };
    Object.keys(map).forEach(function (k) { var el = $('#' + k); if (el) el.textContent = map[k]; });
  }

  /* ---------------------------------------------------------- FILTERS */
  function allTags() {
    var t = [];
    all.forEach(function (x) { (x.tags || []).forEach(function (v) { if (v !== 'kosong' && t.indexOf(v) < 0) t.push(v); }); });
    return t.sort();
  }

  function renderFilters() {
    var host = $('#filters'); if (!host) return;
    var tags = allTags();
    var html = '<button type="button" class="chip is-active" data-tag="semua">Semua <small>' + all.length + '</small></button>';
    tags.forEach(function (t) {
      var n = all.filter(function (x) { return (x.tags || []).indexOf(t) >= 0; }).length;
      html += '<button type="button" class="chip" data-tag="' + esc(t) + '">' + esc(t) + ' <small>' + n + '</small></button>';
    });
    host.innerHTML = html;
    host.addEventListener('click', function (e) {
      var b = e.target.closest('.chip'); if (!b) return;
      $$('.chip', host).forEach(function (c) { c.classList.remove('is-active'); });
      b.classList.add('is-active');
      active = b.getAttribute('data-tag');
      renderGrid();
    });
  }

  /* ------------------------------------------------------------ GRID */
  function matches(x) {
    if (active !== 'semua' && (x.tags || []).indexOf(active) < 0) return false;
    if (!query) return true;
    var hay = (x.title + ' ' + x.caption + ' ' + (x.tags || []).join(' ') + ' ' + x.date + ' ' + x.place).toLowerCase();
    return hay.indexOf(query) >= 0;
  }

  function cardHTML(x) {
    var inner;
    if (x.filled) {
      // Poster = thumbnail. Tanpa poster, tampilkan frame gelap + tombol play.
      // Video TIDAK pernah dimuat di grid (preload="none"), abiding aturan tanpa autoplay massal.
      inner = x.poster
        ? '<img src="' + esc(x.poster) + '" alt="" loading="lazy" decoding="async">'
        : '<div class="vthumb"><span class="vthumb__ph">Thumbnail</span></div>';
    } else {
      inner = '<div class="slotph"><div class="slotph__box"><span class="slotph__idx">' + pad(x.idx + 1) +
        '</span><span class="slotph__txt">Slot video kosong</span></div></div>';
    }

    return '<article class="vitem' + (x.filled ? '' : ' is-empty') + '" data-i="' + x.idx + '" tabindex="0" role="button" aria-label="Putar ' + esc(x.title) + '">' +
      '<figure class="vitem__frame">' + inner +
      '<span class="vitem__idx">' + pad(x.idx + 1) + '</span>' +
      (x.duration ? '<span class="vitem__dur">' + esc(x.duration) + '</span>' : '') +
      (x.date ? '<span class="vitem__date">' + esc(x.date) + '</span>' : '') +
      '<span class="vitem__play" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="none" stroke="currentColor" stroke-width="1.2" opacity=".55"/><path d="M10 8.2l6 3.8-6 3.8z" fill="currentColor"/></svg></span>' +
      '</figure>' +
      '<div class="vitem__meta">' +
      '<h3 class="vitem__title">' + esc(x.title) + '</h3>' +
      (x.caption ? '<p class="vitem__cap">' + esc(x.caption) + '</p>' : '') +
      '<div class="vitem__tags">' + (x.tags || []).filter(function (t) { return t !== 'kosong'; })
        .map(function (t) { return '<span>' + esc(t) + '</span>'; }).join('') +
      (x.place ? '<span class="vitem__place">' + esc(x.place) + '</span>' : '') + '</div>' +
      '</div></article>';
  }

  function renderGrid() {
    var list = all.filter(matches);
    grid.innerHTML = list.map(cardHTML).join('');
    var empty = $('#emptyState');
    if (empty) empty.hidden = list.length > 0;
  }

  /* --------------------------------------------------- LAZY POSTER */
  function loadPosters() {
    $$('img[data-src]', grid).forEach(function (im) { im.src = im.getAttribute('data-src'); im.removeAttribute('data-src'); });
  }

  /* ---------------------------------------------------------- EVENTS */
  function openAt(idx) {
    var list = all.filter(matches);
    var pos = 0;
    for (var i = 0; i < list.length; i++) if (list[i].idx === idx) { pos = i; break; }
    if (window.Lightbox) window.Lightbox.open(list, pos, 'video');
  }

  grid.addEventListener('click', function (e) {
    var c = e.target.closest('.vitem'); if (!c) return;
    openAt(+c.getAttribute('data-i'));
  });
  grid.addEventListener('keydown', function (e) {
    var c = e.target.closest('.vitem'); if (!c) return;
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openAt(+c.getAttribute('data-i')); }
  });

  var search = $('#searchInput');
  if (search) {
    var tmr = null;
    search.addEventListener('input', function () {
      clearTimeout(tmr);
      tmr = setTimeout(function () {
        query = search.value.trim().toLowerCase();
        renderGrid();
      }, 180);
    });
  }

  var hint = $('#fillHint');
  if (hint) {
    hint.addEventListener('click', function () {
      if (window.Lightbox) {
        window.Lightbox.open([{
          kind: 'video', idx: 0, filled: false,
          title: 'Cara mengisi slot video',
          caption: '1) Taruh file .mp4 atau .webm di folder assets/videos/. ' +
                   '2) Buka data/portfolio-data.js pada bagian videos.items. ' +
                   '3) Isi src (contoh: assets/videos/karya-01.mp4) dan poster untuk thumbnail (contoh: assets/images/thumbnails/karya-01.jpg). ' +
                   '4) Isi title, caption, tags, date, dan duration. ' +
                   '5) Simpan, refresh. Slot kosong tetap tampil sebagai placeholder, tidak error.',
          tags: ['panduan', 'offline-first']
        }], 0, 'video');
      }
    });
  }

  /* ------------------------------------------------------------ BOOT */
  renderStats();
  renderFilters();
  renderGrid();
  loadPosters();
})();
