/* ==========================================================================
   script.js — LOGIC UTAMA
   Modules: Data binding, Ambient canvas, Clock, Calendar, Reveal, Tilt,
            Pizza Wheel 16 slice, Dynamic preview aspect, Dashboard, Diagram,
            Footer, Topbar, Soundscape (Web Audio synth), Lightbox.
   Tanpa dependensi eksternal. Semua data dari window.PORTFOLIO_DATA.
   ========================================================================== */
(function () {
  'use strict';

  /* ------------------------------------------------------------- UTIL */
  var D = window.PORTFOLIO_DATA || {};
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var rootPrefix = document.body.getAttribute('data-root') || '.';
  function asset(p) {
    if (!p) return '';
    if (/^(https?:)?\/\//.test(p) || p.charAt(0) === '#') return p;
    return rootPrefix === '.' ? p : ('../' + p.replace(/^\.\.\//, ''));
  }
  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmtDateID(d) {
    return new Intl.DateTimeFormat('id-ID', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }).format(d);
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function toast(msg) {
    var t = $('#toast'); if (!t) return;
    t.textContent = msg; t.classList.add('is-show');
    clearTimeout(t._t); t._t = setTimeout(function () { t.classList.remove('is-show'); }, 3800);
  }

  /* Normalisasi koleksi media: lengkapi hingga `total` dengan placeholder. */
  function buildCollection(cfg, kind) {
    cfg = cfg || {};
    var items = (cfg.items || []).map(function (it, i) {
      it = it || {};
      var src = (it.src || '').trim();
      var has = !!src;
      return {
        kind: kind,
        idx: i,
        id: kind + '-' + i,
        src: has ? asset(src) : '',
        poster: (it.poster && it.poster.trim()) ? asset(it.poster.trim()) : '',
        title: it.title || ('Slot ' + pad(i + 1)),
        caption: it.caption || '',
        tags: Array.isArray(it.tags) && it.tags.length ? it.tags : ['belum-diisi'],
        date: it.date || '',
        place: it.place || '',
        duration: it.duration || '',
        featured: !!it.featured,
        filled: has
      };
    });
    var total = Math.max(Number(cfg.total) || 0, items.length, 50);
    for (var i = items.length; i < total; i++) {
      items.push({
        kind: kind, idx: i, id: kind + '-' + i, src: '', poster: '',
        title: 'Slot ' + pad(i + 1), caption: '', tags: ['kosong'],
        date: '', place: '', duration: '', featured: false, filled: false
      });
    }
    return items;
  }

  var PHOTOS = buildCollection(D.photos, 'foto');
  var VIDEOS = buildCollection(D.videos, 'video');
  window.__MEDIA = { photos: PHOTOS, videos: VIDEOS };

  /* ------------------------------------------------- 1. DATA BINDING */
  function bindData() {
    $$('[data-bind]').forEach(function (el) {
      var path = el.getAttribute('data-bind').split('.');
      var v = D;
      for (var i = 0; i < path.length; i++) { if (v == null) break; v = v[path[i]]; }
      if (typeof v === 'string' || typeof v === 'number') el.textContent = v;
    });
    $$('[data-bind-img]').forEach(function (el) {
      var path = el.getAttribute('data-bind-img').split('.');
      var v = D;
      for (var i = 0; i < path.length; i++) { if (v == null) break; v = v[path[i]]; }
      if (v) el.src = asset(v);
    });

    // Bio body + facts
    var body = $('#bioBody');
    if (body && D.profile && Array.isArray(D.profile.body)) {
      body.innerHTML = D.profile.body.map(function (p) { return '<p>' + esc(p) + '</p>'; }).join('');
    }
    var facts = $('#bioFacts');
    if (facts && D.profile && Array.isArray(D.profile.facts)) {
      facts.innerHTML = D.profile.facts.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('');
    }

    // Copyright dinamis
    var yr = new Date().getFullYear();
    var cp = $('#copyright');
    if (cp) cp.innerHTML = '&copy; ' + yr + ' ' + esc((D.footer && D.footer.copyrightOwner) || 'ir_');

    // Social links
    var sl = $('#socialList');
    if (sl && Array.isArray(D.social)) {
      sl.innerHTML = D.social.map(function (s) {
        var href = asset(s.url);
        return '<li><a href="' + esc(href) + '"' + (/^https?:/.test(s.url) ? ' target="_blank" rel="noopener noreferrer"' : '') + '>' +
          esc(s.label) + ' <small>' + esc(s.handle) + '</small></a></li>';
      }).join('');
    }
    var stamp = $('#buildStamp');
    if (stamp && D.release) stamp.textContent = D.release.codename + ' · ' + D.release.build;
  }

  /* ------------------------------------------ 2. AMBIENT GLOW CANVAS */
  function ambient() {
    var cv = $('#ambient'); if (!cv) return;
    var ctx = cv.getContext('2d');
    var blobs = [
      { c: [26, 51, 114], a: .55, r: .42, x: .18, y: .12, vx: .00020, vy: .00013 },
      { c: [39, 74, 151], a: .40, r: .38, x: .84, y: .26, vx: -.00017, vy: .00016 },
      { c: [12, 28, 66],  a: .70, r: .50, x: .52, y: .96, vx: .00011, vy: -.00014 },
      { c: [143, 176, 238], a: .16, r: .26, x: .62, y: .58, vx: -.00023, vy: -.00019 }
    ];
    var mx = .5, my = .4, tx = .5, ty = .4;
    var W = 0, H = 0, dpr = 1;

    function size() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = window.innerWidth; H = window.innerHeight;
      cv.width = Math.floor(W * dpr); cv.height = Math.floor(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    size();
    window.addEventListener('resize', size, { passive: true });
    window.addEventListener('pointermove', function (e) {
      tx = e.clientX / W; ty = e.clientY / H;
    }, { passive: true });

    function rgba(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }

    function frame() {
      ctx.clearRect(0, 0, W, H);
      // base
      var bg = ctx.createLinearGradient(0, 0, W * .4, H);
      bg.addColorStop(0, '#04091a'); bg.addColorStop(.55, '#050d24'); bg.addColorStop(1, '#03071a');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);

      mx += (tx - mx) * .045; my += (ty - my) * .045;

      for (var i = 0; i < blobs.length; i++) {
        var b = blobs[i];
        if (!reduced) { b.x += b.vx; b.y += b.vy;
          if (b.x < -.2 || b.x > 1.2) b.vx *= -1;
          if (b.y < -.2 || b.y > 1.2) b.vy *= -1;
        }
        var cx = (b.x * .82 + mx * .18) * W;
        var cy = (b.y * .82 + my * .18) * H;
        var rad = b.r * Math.max(W, H) * (0.9 + 0.1 * Math.sin(Date.now() / 5200 + i));
        var g = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad);
        g.addColorStop(0, rgba(b.c, b.a));
        g.addColorStop(.55, rgba(b.c, b.a * .35));
        g.addColorStop(1, rgba(b.c, 0));
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
      }
      requestAnimationFrame(frame);
    }
    frame();
  }

  /* ------------------------------------------------ 3. CLOCK REALTIME */
  function clock() {
    var tEl = $('#clockTime'), dEl = $('#clockDate'), bEl = $('#bigClock'), bdEl = $('#bigDate');
    if (!tEl && !bEl) return;
    var tz = (D.profile && D.profile.timezone) || undefined;
    function tick() {
      var now = new Date();
      var hh, mm, ss;
      // id-ID memakai pemisah "." pada locale, jadi ambil bagian per-field.
      try {
        var parts = new Intl.DateTimeFormat('id-ID', {
          hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: tz
        }).formatToParts(now);
        var map = {};
        parts.forEach(function (p) { if (p.type !== 'literal') map[p.type] = p.value; });
        hh = map.hour; mm = map.minute; ss = map.second;
        if (hh === '24') hh = '00';               // beberapa engine mengembalikan 24 untuk tengah malam
      } catch (e) { hh = pad(now.getHours()); mm = pad(now.getMinutes()); ss = pad(now.getSeconds()); }
      if (!hh || !mm) { hh = pad(now.getHours()); mm = pad(now.getMinutes()); ss = ss || pad(now.getSeconds()); }
      if (tEl) tEl.textContent = hh + ':' + mm + ':' + ss;
      if (bEl) bEl.textContent = hh + ':' + mm;
      var ds;
      try { ds = new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: tz }).format(now); }
      catch (e) { ds = fmtDateID(now); }
      if (dEl) dEl.textContent = ds;
      if (bdEl) bdEl.textContent = ds;
    }
    tick(); setInterval(tick, 1000);
  }

  /* --------------------------------------- 4. MINI CALENDAR INTERAKTIF */
  function calendar() {
    var wrap = $('#calendar'); if (!wrap) return;
    var headEl = $('#calHead'), bodyEl = $('#calBody'), monEl = $('#calMonth'), noteEl = $('#calNote');
    var notes = (D.calendar && D.calendar.notes) || {};
    var today = new Date();
    var view = new Date(today.getFullYear(), today.getMonth(), 1);
    var DOW = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
    var MON = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

    headEl.innerHTML = DOW.map(function (d) { return '<span>' + d + '</span>'; }).join('');

    function key(y, m, d) { return y + '-' + pad(m + 1) + '-' + pad(d); }

    function render() {
      monEl.textContent = MON[view.getMonth()] + ' ' + view.getFullYear();
      var first = new Date(view.getFullYear(), view.getMonth(), 1);
      var start = first.getDay();
      var days = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
      var prevDays = new Date(view.getFullYear(), view.getMonth(), 0).getDate();
      var cells = [];
      var i;
      for (i = start; i > 0; i--) cells.push({ d: prevDays - i + 1, out: true, m: view.getMonth() - 1 });
      for (i = 1; i <= days; i++) cells.push({ d: i, out: false, m: view.getMonth() });
      while (cells.length % 7 !== 0) cells.push({ d: cells.length - start - days + 1, out: true, m: view.getMonth() + 1 });

      bodyEl.innerHTML = cells.map(function (c) {
        var mIdx = c.m;
        var y = view.getFullYear();
        if (mIdx < 0) { mIdx += 12; y -= 1; }
        if (mIdx > 11) { mIdx -= 12; y += 1; }
        var k = key(y, mIdx, c.d);
        var isToday = !c.out && k === key(today.getFullYear(), today.getMonth(), today.getDate());
        var cls = 'calcell' + (c.out ? ' is-out' : '') + (isToday ? ' is-today' : '') + (notes[k] ? ' has-note' : '');
        return '<button type="button" class="' + cls + '" data-k="' + k + '"' + (c.out ? ' disabled' : '') + '>' + c.d + '</button>';
      }).join('');
    }

    bodyEl.addEventListener('click', function (e) {
      var b = e.target.closest('.calcell'); if (!b || b.disabled) return;
      $$('.calcell.is-sel', bodyEl).forEach(function (x) { x.classList.remove('is-sel'); });
      b.classList.add('is-sel');
      var k = b.getAttribute('data-k');
      if (notes[k]) { noteEl.textContent = notes[k]; noteEl.classList.add('is-note'); }
      else {
        var parts = k.split('-');
        noteEl.classList.remove('is-note');
        noteEl.textContent = parts[2] + ' ' + MON[+parts[1] - 1] + ' ' + parts[0] + ' — belum ada catatan. Ini juga bagian dari catatan.';
      }
    });

    $('#calPrev').addEventListener('click', function () { view.setMonth(view.getMonth() - 1); render(); });
    $('#calNext').addEventListener('click', function () { view.setMonth(view.getMonth() + 1); render(); });
    render();
  }

  /* ------------------------------------------------- 5. REVEAL ENGINE */
  function reveal() {
    var els = $$('[data-reveal]');
    if (!('IntersectionObserver' in window)) { els.forEach(function (e) { e.classList.add('is-in'); }); return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
      });
    }, { threshold: .12, rootMargin: '0px 0px -6% 0px' });
    els.forEach(function (e) { io.observe(e); });
  }

  /* ------------------------------------------- 6. 3D MOUSE TILT (max 15deg) */
  function tilt() {
    var els = $$('[data-tilt]');
    if (reduced || !window.matchMedia('(hover:hover)').matches) return;

    // Scroll-driven cinematic zoom pada layer media hero.
    // Dipisah dari tilt supaya keduanya tidak saling menimpa transform.
    var heroMedia = $('#heroMedia');
    if (heroMedia) {
      var hQueued = false, hScale = 1;
      window.addEventListener('scroll', function () {
        if (hQueued) return;
        hQueued = true;
        requestAnimationFrame(function () {
          hQueued = false;
          if (window.scrollY > window.innerHeight * 1.4) return;   // sudah jauh, berhenti kerja
          var fig = heroMedia.closest('.hero-figure');
          var top = fig ? fig.offsetTop : 0;
          var h = fig ? fig.offsetHeight : 1;
          // 0 -> 1 saat hero melewati tengah layar
          var prog = clamp(1 - (top + h - window.scrollY) / (window.innerHeight * .9), 0, 1);
          var goal = 1 + prog * 0.14;
          hScale += (goal - hScale) * 0.1;
          if (Math.abs(goal - hScale) < 0.002) hScale = goal;
          heroMedia.style.transform = 'scale(' + hScale.toFixed(4) + ')';
        });
      }, { passive: true });
    }

    els.forEach(function (el) {
      var max = parseFloat(el.getAttribute('data-tilt-max')) || 15;
      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect();
        var px = (e.clientX - r.left) / r.width - .5;
        var py = (e.clientY - r.top) / r.height - .5;
        var rx = clamp(-py * max * 2, -max, max);
        var ry = clamp(px * max * 2, -max, max);
        el.classList.add('is-tilting');
        el.style.transform = 'perspective(1100px) rotateX(' + rx.toFixed(2) + 'deg) rotateY(' + ry.toFixed(2) + 'deg) translateZ(0)';
      });
      el.addEventListener('pointerleave', function () {
        el.classList.remove('is-tilting');
        el.style.transform = '';
      });
    });
  }

  /* --------------------------- 7. PIZZA WHEEL — 16 SLICE INTERACTIVE */
  function wheel() {
    var wheelEl = $('#wheel'), rotor = $('#wheelRotor');
    if (!wheelEl || !rotor) return;
    var SLICES = (D.curation && D.curation.wheelSlices) || 16;
    var pool = PHOTOS.concat(VIDEOS);
    var n = Math.min(SLICES, pool.length);

    // Siapkan slice
    var frags = [];
    for (var i = 0; i < n; i++) {
      var a0 = (i / SLICES) * 360 - 90;
      var a1 = ((i + 1) / SLICES) * 360 - 90;
      var mid = ((i + 0.5) / SLICES) * 360;
      var item = pool[i];
      var clipPath = 'polygon(50% 50%,' + pt(a1) + ',' + pt(a0) + ')';
      var label = pad(i + 1);
      var inner = '';
      if (item.filled && item.src) {
        inner = '<span class="slice__clip"><img class="has-img" data-src="' + esc(item.src) + '" alt="' + esc(item.title) + '"></span>';
      } else {
        inner = '<span class="slice__clip"></span>';
      }
      var kind = item.kind === 'video' ? 'VID' : 'PIC';
      frags.push(
        '<button type="button" class="slice" data-rot="' + mid + '" data-clip="' + esc(clipPath) + '"' +
        ' data-idx="' + item.idx + '" data-kind="' + item.kind + '" aria-label="Slice ' + label + ': ' + esc(item.title) + '">' +
        inner + '<span class="slice__num">' + label + '</span><span class="slice__kind">' + kind + '</span></button>'
      );
    }
    function pt(deg) {
      var r = 50, a = deg * Math.PI / 180;
      return (50 + r * Math.cos(a)).toFixed(2) + '% ' + (50 + r * Math.sin(a)).toFixed(2) + '%';
    }
    rotor.innerHTML = frags.join('');

    var slices = $$('.slice', rotor);
    slices.forEach(function (sl) {
      var rot = parseFloat(sl.getAttribute('data-rot'));
      sl.style.setProperty('--rot', rot + 'deg');
      sl.querySelector('.slice__clip').style.clipPath = sl.getAttribute('data-clip');
      sl.style.setProperty('--numr', '38%');

      sl.addEventListener('pointerenter', function () {
        wheelEl.classList.add('is-lit');
        var a = rot * Math.PI / 180;
        wheelEl.style.setProperty('--gx', (50 + 34 * Math.cos(a)).toFixed(1) + '%');
        wheelEl.style.setProperty('--gy', (50 + 34 * Math.sin(a)).toFixed(1) + '%');
      });
      sl.addEventListener('pointerleave', function () { wheelEl.classList.remove('is-lit'); });
      sl.addEventListener('click', function () {
        slices.forEach(function (x) { x.classList.remove('is-active'); });
        sl.classList.add('is-active');
        var item = findMedia(sl.getAttribute('data-kind'), +sl.getAttribute('data-idx'));
        Lightbox.open(item ? [item] : [], item ? item.idx : 0, sl.getAttribute('data-kind'));
      });
    });

    // Lazy-load gambar slice saat wheel terlihat
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (en) {
        en.forEach(function (x) {
          if (!x.isIntersecting) return;
          $$('img[data-src]', x.target).forEach(function (im) { im.src = im.getAttribute('data-src'); im.removeAttribute('data-src'); });
          io.unobserve(x.target);
        });
      }, { rootMargin: '120px' });
      io.observe(wheelEl);
    }

    // Rotasi lambat konstan (respect reduced-motion)
    var angle = 0, paused = false;
    wheelEl.addEventListener('pointerenter', function () { paused = true; });
    wheelEl.addEventListener('pointerleave', function () { paused = false; });
    (function spin() {
      if (!paused && !reduced) {
        angle = (angle + 0.035) % 360;
        rotor.style.transform = 'rotate(' + angle + 'deg)';
        wheelEl.style.setProperty('--rotor', angle.toFixed(2) + 'deg');
      }
      requestAnimationFrame(spin);
    })();
  }

  function findMedia(kind, idx) {
    var arr = kind === 'video' ? VIDEOS : PHOTOS;
    for (var i = 0; i < arr.length; i++) if (arr[i].idx === idx) return arr[i];
    return arr[idx];
  }

  /* ------------------- 8. DYNAMIC PREVIEW ASPECT (device-scroll) */
  function preview() {
    var row = $('[data-preview]'); if (!row) return;
    var photoStack = $('#photoStack'), videoStack = $('#videoStack');
    var pCount = (D.curation && D.curation.photoPreview) || 3;
    var vCount = (D.curation && D.curation.videoPreview) || 3;

    var pFeat = PHOTOS.filter(function (p) { return p.featured; });
    var pSel = (pFeat.length ? pFeat : PHOTOS).slice(0, pCount);
    var vFeat = VIDEOS.filter(function (v) { return v.featured; });
    var vSel = (vFeat.length ? vFeat : VIDEOS).slice(0, vCount);

    function frameHTML(item) {
      if (item.filled && item.src) {
        if (item.kind === 'video') {
          // Tanpa autoplay (sesuai PRD). Kontrol native per-item di dalam stack.
          var poster = item.poster ? ' poster="' + esc(item.poster) + '"' : '';
          return '<video' + poster + ' playsinline muted loop preload="metadata" controls>' +
            '<source src="' + esc(item.src) + '"></video>';
        }
        return '<img src="' + esc(item.src) + '" alt="' + esc(item.title) + '" loading="lazy">';
      }
      return '<div class="is-empty"><div class="slotph"><div class="slotph__box">' +
        '<span class="slotph__idx">' + pad(item.idx + 1) + '</span>' +
        '<span class="slotph__txt">Slot siap diisi. Letakkan media lokal lalu isi <code>src</code>.</span></div></div></div>';
    }
    function stackHTML(list) {
      return list.map(function (it, i) {
        return '<div class="preview-stack__item' + (i === 0 ? ' is-active' : '') + '">' + frameHTML(it) + '</div>';
      }).join('');
    }
    photoStack.innerHTML = stackHTML(pSel);
    videoStack.innerHTML = stackHTML(vSel);

    // Dots
    [$('#photoScreen'), $('#videoScreen')].forEach(function (screen) {
      if (!screen) return;
      var items = screen.querySelectorAll('.preview-stack__item');
      if (items.length < 2) return;
      var dots = document.createElement('div');
      dots.className = 'preview-dots';
      dots.innerHTML = Array.prototype.map.call(items, function (_, i) {
        return '<button type="button" class="' + (i === 0 ? 'is-active' : '') + '" data-i="' + i + '" aria-label="Preview ' + (i + 1) + '"></button>';
      }).join('');
      screen.appendChild(dots);
      var cur = 0, timer = null;

      function show(n) {
        cur = (n + items.length) % items.length;
        for (var k = 0; k < items.length; k++) items[k].classList.toggle('is-active', k === cur);
        var bs = dots.querySelectorAll('button');
        for (var j = 0; j < bs.length; j++) bs[j].classList.toggle('is-active', j === cur);
      }
      function advance() {
        if (screen.offsetParent === null) return;   // hemat resource saat di luar layar
        show(cur + 1);
      }
      function startAuto() { clearInterval(timer); timer = setInterval(advance, 4200); }
      function stopAuto() { clearInterval(timer); timer = null; }

      show(0);
      startAuto();

      dots.addEventListener('click', function (e) {
        var b = e.target.closest('button'); if (!b) return;
        show(+b.getAttribute('data-i'));
        startAuto();
      });
      screen.addEventListener('pointerenter', stopAuto);
      screen.addEventListener('pointerleave', startAuto);

      // Klik slide -> arahkan ke galeri terkait (spec: click state)
      var galleryHref = screen.id === 'videoScreen' ? 'pages/gallery-video.html' : 'pages/gallery-foto.html';
      screen.style.cursor = 'pointer';
      screen.addEventListener('click', function (e) {
        if (e.target.closest('.preview-dots')) return;
        window.location.href = galleryHref;
      });
      screen.setAttribute('role', 'link');
      screen.setAttribute('tabindex', '0');
      screen.setAttribute('aria-label', 'Buka galeri lengkap');
      screen.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); window.location.href = galleryHref; }
      });
    });

    // Dynamic height mengikuti device.
    // baseH disimpan terpisah dari --preview-h agar zoom sinematik di bawah
    // tidak menumpuk/menfeed balik ke nilai yang sama.
    var baseH = 0;
    function computeBase() {
      var w = window.innerWidth;
      var vh = window.innerHeight;
      return w < 640 ? clamp(vh * 0.52, 260, 520)
           : w < 1024 ? clamp(vh * 0.56, 320, 640)
           : clamp(vh * 0.6, 360, 760);
    }
    function applyH() {
      document.documentElement.style.setProperty('--preview-h', Math.round(baseH * curZoom) + 'px');
    }
    var curZoom = 1;                       // 1 = netral, diubah oleh scroll di bawah
    function setH() {
      baseH = computeBase();
      applyH();
    }
    setH();
    window.addEventListener('resize', setH, { passive: true });
    window.addEventListener('orientationchange', function () { setTimeout(setH, 120); }, { passive: true });

    // Rasio menyesuaikan posisi scroll (cinematic), dihalus-rAPI via rAF.
    // Memakai baseH sebagai acuan, bukan nilai CSS yang sedang aktif.
    if (!reduced) {
      var queued = false;
      function onScroll() {
        if (queued) return;
        queued = true;
        requestAnimationFrame(function () {
          queued = false;
          var r = row.getBoundingClientRect();
          var prog = clamp((window.innerHeight - r.top) / (window.innerHeight + r.height), 0, 1);
          var goal = 0.92 + prog * 0.16;             // 0.92 -> 1.08
          curZoom += (goal - curZoom) * 0.12;        // smooth interpolation
          if (Math.abs(goal - curZoom) < 0.002) curZoom = goal;
          applyH();
        });
      }
      window.addEventListener('scroll', onScroll, { passive: true });
    }
  }

  /* ------------------------------------ 9. DASHBOARD: STATS + SKILLS + TIMELINE */
  function dashboard() {
    var sg = $('#statGrid');
    if (sg) {
      var filledP = PHOTOS.filter(function (x) { return x.filled; }).length;
      var filledV = VIDEOS.filter(function (x) { return x.filled; }).length;
      var since = (D.profile && D.profile.since) ? new Date(D.profile.since) : null;
      var days = since ? Math.max(1, Math.round((Date.now() - since.getTime()) / 86400000)) : 0;
      var rows = [
        [D.stats ? D.stats.projects : 0, 'Proyek'],
        [PHOTOS.length + VIDEOS.length, 'Total Slot Media'],
        [filledP, 'Foto Terisi'],
        [filledV, 'Video Terisi'],
        [days.toLocaleString('id-ID'), 'Hari Tercatat'],
        [D.stats ? D.stats.hoursLogged : 0, 'Jam Tercatat']
      ];
      sg.innerHTML = rows.map(function (r) {
        return '<li><b data-count="' + r[0] + '">' + r[0] + '</b><span>' + esc(r[1]) + '</span></li>';
      }).join('');
      // count-up
      if (!reduced) {
        $$('[data-count]', sg).forEach(function (el) {
          var target = Number(el.getAttribute('data-count')) || 0;
          if (!isFinite(target) || target > 999999) return;
          var start = null, dur = 1400;
          function step(t) {
            if (!start) start = t;
            var p = clamp((t - start) / dur, 0, 1);
            var e = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.round(target * e).toLocaleString('id-ID');
            if (p < 1) requestAnimationFrame(step);
          }
          requestAnimationFrame(step);
        });
      }
    }

    // Skills
    var sk = $('#skillList');
    if (sk && Array.isArray(D.skills)) {
      sk.innerHTML = D.skills.map(function (s, i) {
        return '<div class="skill">' +
          '<div class="skill__top"><span class="skill__name">' + esc(s.name) + '</span><span class="skill__val">' + s.level + '%</span></div>' +
          '<div class="skill__track" title="' + esc(s.note || '') + '"><span class="skill__fill" data-lvl="' + s.level + '" style="transition-delay:' + (i * .07) + 's"></span></div>' +
          '</div>';
      }).join('');
      // Isi bar saat masuk viewport. Threshold 0 + rootMargin longgar supaya
      // tetap terisi di viewport pendek (mis. 484px tinggi) maupun mobile.
      var fills = $$('.skill__fill', sk);
      function fillAll() {
        fills.forEach(function (f) { f.style.width = f.getAttribute('data-lvl') + '%'; });
      }
      if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (en) {
          en.forEach(function (x) {
            if (x.isIntersecting) { fillAll(); io.disconnect(); }
          });
        }, { threshold: 0, rootMargin: '0px 0px -10% 0px' });
        io.observe(sk);
        // Jaring pengaman: bila observer tidak pernah memicu (mis. elemen
        // di dalam wadah yang tidak bisa di-scroll), isi tetap setelah 2,5 detik.
        setTimeout(function () { fillAll(); io.disconnect(); }, 2500);
      } else {
        fillAll();
      }
    }

    // Timeline
    var tl = $('#timeline');
    if (tl && Array.isArray(D.timeline)) {
      tl.innerHTML = D.timeline.map(function (t) {
        return '<li><span class="timeline__year">' + esc(t.year) + '</span>' +
          '<h4 class="timeline__title">' + esc(t.title) + '</h4>' +
          '<p class="timeline__text">' + esc(t.text) + '</p></li>';
      }).join('');
    }
    var sb = $('#sinceBadge');
    if (sb && D.profile && D.profile.since) sb.textContent = 'Sejak ' + D.profile.since;

    diagram();
  }

  /* ------------------------------- 10. INTERACTIVE DIAGRAM (SVG, nyata) */
  function diagram() {
    var host = $('#diagram'); if (!host) return;
    var cfg = D.diagram || { nodes: [], ribbons: [] };
    var NS = 'http://www.w3.org/2000/svg';
    var W = 100, H = 60;
    var nodes = {};
    cfg.nodes.forEach(function (n) { nodes[n.id] = n; });

    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', 'Diagram hubungan Art, Culture, dan Technology');
    svg.innerHTML =
      '<defs>' +
      '<linearGradient id="ribbonGrad" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0%" stop-color="#4b76d4"/><stop offset="50%" stop-color="#8fb0ee"/>' +
      '<stop offset="100%" stop-color="#ffffff"/></linearGradient>' +
      '<radialGradient id="coreGrad"><stop offset="0%" stop-color="#fff"/><stop offset="100%" stop-color="#8fb0ee"/></radialGradient>' +
      '</defs>';

    // Ribbons (kurva bezier nyata)
    var ribbonLayer = document.createElementNS(NS, 'g');
    var ribbonEls = [];
    (cfg.ribbons || []).forEach(function (r, i) {
      var a = nodes[r.from], b = nodes[r.to];
      if (!a || !b) return;
      var path = document.createElementNS(NS, 'path');
      var mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      var dx = b.x - a.x, dy = b.y - a.y;
      // kontrol point tegak lurus -> busur melted
      var cx = mx - dy * .18, cy = my + dx * .18;
      path.setAttribute('d', 'M' + a.x + ' ' + a.y + ' Q' + cx + ' ' + cy + ' ' + b.x + ' ' + b.y);
      path.setAttribute('class', 'dribbon');
      path.setAttribute('stroke-width', r.weight * .5);
      path.style.animationDelay = (i * .35) + 's';
      path.dataset.from = r.from; path.dataset.to = r.to;
      ribbonLayer.appendChild(path);
      ribbonEls.push(path);
    });
    svg.appendChild(ribbonLayer);

    // Core
    var core = document.createElementNS(NS, 'g');
    var ccx = (cfg.nodes[0] ? cfg.nodes[0].x : 50), ccy = 30;
    if (cfg.nodes.length === 3) {
      ccx = (cfg.nodes[0].x + cfg.nodes[1].x + cfg.nodes[2].x) / 3;
      ccy = (cfg.nodes[0].y + cfg.nodes[1].y + cfg.nodes[2].y) / 3;
    }
    var coreC = document.createElementNS(NS, 'circle');
    coreC.setAttribute('cx', ccx); coreC.setAttribute('cy', ccy); coreC.setAttribute('r', 2.6);
    coreC.setAttribute('fill', 'url(#coreGrad)');
    coreC.setAttribute('opacity', '.9');
    core.appendChild(coreC);
    var coreX = document.createElementNS(NS, 'text');
    coreX.setAttribute('x', ccx); coreX.setAttribute('y', ccy + .8);
    coreX.setAttribute('text-anchor', 'middle');
    coreX.setAttribute('font-size', '2'); coreX.setAttribute('fill', '#03071a');
    coreX.setAttribute('font-weight', '700');
    coreX.textContent = '×';
    core.appendChild(coreX);
    svg.appendChild(core);

    // Nodes
    var nodeLayer = document.createElementNS(NS, 'g');
    var nodeEls = [];
    (cfg.nodes || []).forEach(function (n) {
      var g = document.createElementNS(NS, 'g');
      g.setAttribute('class', 'dnode');
      g.setAttribute('tabindex', '0');
      g.setAttribute('role', 'button');
      g.dataset.id = n.id;
      var c1 = document.createElementNS(NS, 'circle');
      c1.setAttribute('class', 'dnode__halo'); c1.setAttribute('cx', n.x); c1.setAttribute('cy', n.y); c1.setAttribute('r', 6);
      var t1 = document.createElementNS(NS, 'text');
      t1.setAttribute('x', n.x); t1.setAttribute('y', n.y + .6); t1.setAttribute('text-anchor', 'middle');
      t1.setAttribute('font-size', '2.4'); t1.setAttribute('font-weight', '600'); t1.textContent = n.label;
      var t2 = document.createElementNS(NS, 'text');
      t2.setAttribute('class', 'dnode__sub');
      t2.setAttribute('x', n.x); t2.setAttribute('y', n.y + 3.4); t2.setAttribute('text-anchor', 'middle');
      t2.setAttribute('font-size', '1.5'); t2.textContent = n.sub;
      g.appendChild(c1); g.appendChild(t1); g.appendChild(t2);
      nodeLayer.appendChild(g);
      nodeEls.push(g);
    });
    svg.appendChild(nodeLayer);

    host.appendChild(svg);

    var note = $('#diagramNote');
    var defaultNote = (cfg.caption) || 'Arahkan kursor ke salah satu poros untuk membaca catatannya.';
    if (note) note.textContent = defaultNote;

    function focus(id) {
      nodeEls.forEach(function (g) { g.classList.toggle('is-on', g.dataset.id === id); });
      ribbonEls.forEach(function (p) {
        var on = p.dataset.from === id || p.dataset.to === id;
        p.classList.toggle('is-on', !!id && on);
        p.classList.toggle('is-dim', !!id && !on);
      });
      var n = nodes[id];
      if (note && n) note.textContent = n.label + ' — ' + n.note;
    }
    nodeEls.forEach(function (g) {
      g.addEventListener('pointerenter', function () { focus(g.dataset.id); });
      g.addEventListener('focus', function () { focus(g.dataset.id); });
      g.addEventListener('click', function () { focus(g.dataset.id); });
      g.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); focus(g.dataset.id); }
      });
      g.addEventListener('pointerleave', function () {
        nodeEls.forEach(function (x) { x.classList.remove('is-on'); });
        ribbonEls.forEach(function (p) { p.classList.remove('is-on', 'is-dim'); });
        if (note) note.textContent = defaultNote;
      });
    });
  }

  /* ------------------------------------------------ 11. TOPBAR BEHAVIOR */
  function topbar() {
    var tb = $('#topbar'); if (!tb) return;
    window.addEventListener('scroll', function () {
      tb.classList.toggle('is-stuck', window.scrollY > 20);
    }, { passive: true });

    // Gallery dropdown
    var toggle = $('[data-nav-toggle="gallery"]') || $('.nav__item--menu .nav__link--btn');
    var menu = $('#menuGallery');
    if (toggle && menu) {
      toggle.addEventListener('click', function (e) {
        e.stopPropagation();
        var open = menu.hasAttribute('hidden');
        if (open) menu.removeAttribute('hidden'); else menu.setAttribute('hidden', '');
        toggle.setAttribute('aria-expanded', String(open));
        toggle.parentElement.classList.toggle('is-open', open);
      });
      document.addEventListener('click', function (e) {
        if (!menu.hasAttribute('hidden') && !e.target.closest('.nav__item--menu')) {
          menu.setAttribute('hidden', ''); toggle.setAttribute('aria-expanded', 'false');
          toggle.parentElement.classList.remove('is-open');
        }
      });
    }

    // Mobile nav
    var nt = $('.navtoggle'), mn = $('#mobileNav');
    if (nt && mn) {
      nt.addEventListener('click', function () {
        var open = mn.hasAttribute('hidden');
        if (open) mn.removeAttribute('hidden'); else mn.setAttribute('hidden', '');
        nt.setAttribute('aria-expanded', String(open));
      });
    }

    // Smooth scroll untuk anchor internal
    $$('a[href^="#"]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        var id = a.getAttribute('href');
        if (id === '#' || id.length < 2) return;
        var t = document.querySelector(id);
        if (t) { e.preventDefault(); t.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' }); }
      });
    });

    // Active nav via IntersectionObserver
    var secs = ['home', 'projects', 'contact'].map(function (id) { return document.getElementById(id); }).filter(Boolean);
    if (secs.length && 'IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (en) {
        en.forEach(function (x) {
          if (!x.isIntersecting) return;
          $$('.nav__link[data-nav]').forEach(function (l) {
            l.classList.toggle('is-active', l.getAttribute('data-nav') === x.target.id);
          });
        });
      }, { rootMargin: '-45% 0px -50% 0px' });
      secs.forEach(function (s) { io.observe(s); });
    }
  }

  /* ---------------------------- 12. SOUNDSCAPE: Web Audio synth + visualizer */
  var Sound = {
    ctx: null, master: null, analyser: null, data: null,
    playing: false, timer: null, nodes: [], src: null, el: null, viz: null, vizCtx: null,
    chords: [
      [220.00, 261.63, 329.63, 392.00], // Am add-ish
      [196.00, 246.94, 293.66, 392.00],
      [174.61, 220.00, 261.63, 349.23],
      [164.81, 207.65, 246.94, 329.63]
    ],
    init: function () {
      this.el = $('#dock'); if (!this.el) return;
      var self = this;
      var play = $('#dockPlay'), vol = $('#dockVol'), hide = $('#dockHide'), peek = $('#dockPeek');
      this.viz = $('#viz'); if (this.viz) this.vizCtx = this.viz.getContext('2d');

      play.addEventListener('click', function () { self.toggle(); });
      if (vol) {
        var upd = function () { vol.style.setProperty('--fill', vol.value + '%'); };
        vol.addEventListener('input', upd); upd();
        vol.addEventListener('change', function () { if (self.master) self.setVol(vol.value / 100); });
      }
      hide.addEventListener('click', function () {
        self.el.classList.add('is-gone'); self.el.setAttribute('hidden', '');
        peek.hidden = false;
      });
      peek.addEventListener('click', function () {
        self.el.removeAttribute('hidden'); requestAnimationFrame(function () { self.el.classList.remove('is-gone'); });
        peek.hidden = true;
      });
      this.drawIdle();
    },
    ensureCtx: function () {
      if (this.ctx) return;
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { toast('Web Audio tidak tersedia di browser ini.'); return; }
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0;
      var comp = this.ctx.createDynamicsCompressor();
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 64;
      this.data = new Uint8Array(this.analyser.frequencyBinCount);
      this.master.connect(comp); comp.connect(this.analyser); this.analyser.connect(this.ctx.destination);
      this.scheduleChord(0);
      this.tickChord();
    },
    scheduleChord: function (i) {
      var self = this, ctx = this.ctx;
      var chord = this.chords[i % this.chords.length];
      var now = ctx.currentTime;
      // kill previous
      this.nodes.forEach(function (n) {
        try { n.g.gain.cancelScheduledValues(now); n.g.gain.setValueAtTime(n.g.gain.value, now); n.g.gain.linearRampToValueAtTime(0, now + 1.2); n.o.stop(now + 1.4); } catch (e) {}
      });
      this.nodes = [];
      chord.forEach(function (f, k) {
        var o = ctx.createOscillator(); var g = ctx.createGain();
        o.type = k === 0 ? 'sine' : 'triangle';
        o.frequency.value = f;
        // detune shimmer
        o.detune.value = (k % 2 ? 4 : -4) * (i + 1);
        var lfo = ctx.createOscillator(); var lg = ctx.createGain();
        lfo.frequency.value = 0.07 + k * 0.03; lg.gain.value = f * 0.004;
        lfo.connect(lg); lg.connect(o.frequency); lfo.start(now);
        g.gain.setValueAtTime(0, now);
        g.gain.linearRampToValueAtTime(0.055 / (k + 1), now + 2.4);
        o.connect(g); g.connect(self.master);
        o.start(now);
        self.nodes.push({ o: o, g: g, lfo: lfo });
      });
    },
    tickChord: function () {
      var self = this, i = 0;
      this.timer = setInterval(function () { i++; self.scheduleChord(i); }, 8000);
    },
    setVol: function (v) {
      if (!this.master) return;
      var now = this.ctx.currentTime;
      this.master.gain.cancelScheduledValues(now);
      this.master.gain.linearRampToValueAtTime(this.playing ? v * .4 : 0, now + .4);
    },
    toggle: function () {
      var cfg = D.soundscape || {};
      if (cfg.src) return this.toggleFile(cfg.src);
      this.ensureCtx();
      if (!this.ctx) return;
      var self = this;
      if (this.ctx.state === 'suspended') this.ctx.resume();
      this.playing = !this.playing;
      this.el.setAttribute('data-state', this.playing ? 'play' : 'idle');
      $('#dockPlay').setAttribute('aria-pressed', String(this.playing));
      $('#dockPlay').setAttribute('aria-label', this.playing ? 'Jeda ambience' : 'Putar ambience');
      var target = this.playing ? (($('#dockVol') ? +$('#dockVol').value : 55) / 100) * .4 : 0;
      var now = this.ctx.currentTime;
      this.master.gain.cancelScheduledValues(now);
      this.master.gain.linearRampToValueAtTime(target, now + 1.2);
      if (this.playing) this.drawActive(); else this.drawIdle();
    },
    toggleFile: function (src) {
      var url = asset(src);
      if (!this.src) {
        this.src = new Audio(url);
        this.src.loop = true; this.src.crossOrigin = 'anonymous';
        this.src.connect = this.src.connect || function () {};
        var AC = window.AudioContext || window.webkitAudioContext;
        if (AC) { this.ctx = this.ctx || new AC(); this.analyser = this.ctx.createAnalyser(); this.analyser.fftSize = 64;
          this.data = new Uint8Array(this.analyser.frequencyBinCount);
          var ms = this.ctx.createMediaElementSource(this.src); ms.connect(this.analyser); this.analyser.connect(this.ctx.destination); }
        this.src.addEventListener('error', function () { toast('File audio tidak ditemukan: ' + url); self_fallback(); });
        var self_ = this; function self_fallback() { self_.src = null; toast('Gagal memuat audio — beralih ke pad sintetis.'); self_.toggle(); }
      }
      this.playing ? this.src.pause() : this.src.play().catch(function () {});
      this.el.setAttribute('data-state', this.playing ? 'idle' : 'play');
      this.playing = !this.playing;
      this.playing ? this.drawActive() : this.drawIdle();
    },
    drawIdle: function () {
      var c = this.vizCtx, cv = this.viz; if (!c || !cv) return;
      var w = cv.width, h = cv.height;
      c.clearRect(0, 0, w, h);
      c.strokeStyle = 'rgba(255,255,255,.18)'; c.lineWidth = 1;
      c.beginPath(); c.moveTo(0, h / 2); c.lineTo(w, h / 2); c.stroke();
    },
    drawActive: function () {
      var self = this;
      if (this._drawing) return; this._drawing = true;
      function loop() {
        var c = self.vizCtx, cv = self.viz;
        if (!c || !cv) { self._drawing = false; return; }
        var w = cv.width, h = cv.height;
        c.clearRect(0, 0, w, h);
        if (self.analyser && self.playing) {
          self.analyser.getByteFrequencyData(self.data);
          var n = self.data.length, bw = w / n;
          for (var i = 0; i < n; i++) {
            var v = self.data[i] / 255;
            var bh = Math.max(2, v * h * .9);
            var g = c.createLinearGradient(0, h, 0, h - bh);
            g.addColorStop(0, 'rgba(75,118,212,.85)'); g.addColorStop(1, 'rgba(255,255,255,.95)');
            c.fillStyle = g;
            c.fillRect(i * bw + 1, h - bh, Math.max(2, bw - 2), bh);
          }
        } else { self.drawIdle(); self._drawing = false; return; }
        requestAnimationFrame(loop);
      }
      requestAnimationFrame(loop);
    }
  };

  /* ------------------------------------------------ 13. LIGHTBOX (shared) */
  var Lightbox = {
    root: null, current: [], pos: 0, kind: 'foto', lastFocus: null, videoMode: false,
    build: function () {
      if (this.root || !document.body) return;
      var d = document.createElement('div');
      d.className = 'lb'; d.id = 'lightbox'; d.setAttribute('role', 'dialog');
      d.setAttribute('aria-modal', 'true'); d.setAttribute('aria-label', 'Penampil media');
      d.hidden = true;
      d.innerHTML =
        '<div class="lb__bar"><span class="lb__count" id="lbCount"></span>' +
        '<button class="lb__close" id="lbClose" aria-label="Tutup (Esc)"><svg viewBox="0 0 14 14"><path d="M1 1l12 12M13 1L1 13" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button></div>' +
        '<div class="lb__stage" id="lbStage"></div>' +
        '<div class="lb__navrow"><button class="lb__nav" id="lbPrev" aria-label="Sebelumnya"><svg viewBox="0 0 10 16"><path d="M8 1L2 8l6 7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
        '<button class="lb__nav" id="lbNext" aria-label="Berikutnya"><svg viewBox="0 0 10 16"><path d="M2 1l6 7-6 7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>';
      document.body.appendChild(d);
      this.root = d;
      var self = this;
      $('#lbClose', d).addEventListener('click', function () { self.close(); });
      $('#lbPrev', d).addEventListener('click', function () { self.step(-1); });
      $('#lbNext', d).addEventListener('click', function () { self.step(1); });
      $('#lbStage', d).addEventListener('click', function (e) { if (e.target.id === 'lbStage') self.close(); });
      d.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') self.close();
        if (e.key === 'ArrowLeft') self.step(-1);
        if (e.key === 'ArrowRight') self.step(1);
      });
    },
    open: function (list, pos, kind) {
      this.build();
      if (!list || !list.length) return;
      this.current = list; this.pos = clamp(pos || 0, 0, list.length - 1); this.kind = kind || 'foto';
      this.lastFocus = document.activeElement;
      this.root.hidden = false;
      document.body.style.overflow = 'hidden';
      requestAnimationFrame(function () { Lightbox.root.classList.add('is-open'); });
      this.render();
      $('#lbClose', this.root).focus();
    },
    render: function () {
      var it = this.current[this.pos], self = this;
      var stage = $('#lbStage', this.root);
      $('#lbCount', this.root).textContent = (this.pos + 1) + ' / ' + this.current.length;
      var multi = this.current.length > 1;
      $('#lbPrev', this.root).style.visibility = multi ? 'visible' : 'hidden';
      $('#lbNext', this.root).style.visibility = multi ? 'visible' : 'hidden';

      var frameInner;
      if (it.filled && it.src) {
        if (it.kind === 'video') {
          frameInner = '<div class="vplayer"><video id="lbVideo" controls playsinline preload="metadata"' + (it.poster ? ' poster="' + esc(it.poster) + '"' : '') + '><source src="' + esc(it.src) + '"></video>' +
            '<div class="vctrl"><button class="vctrl__btn" id="vPlay" aria-label="Putar/Jeda"><svg viewBox="0 0 16 16"><path d="M4 2.6v10.8L13 8z" fill="currentColor"/></svg></button>' +
            '<span class="vctrl__time" id="vTime">00:00 / 00:00</span>' +
            '<span class="vctrl__seek"><input type="range" id="vSeek" min="0" max="100" value="0" step="0.1" aria-label="Posisi"></span>' +
            '<button class="vctrl__rate" id="vRate">1x</button></div></div>';
        } else {
          frameInner = '<img src="' + esc(it.src) + '" alt="' + esc(it.title) + '">';
        }
      } else {
        frameInner = '<div class="lb__empty"><div class="slotph"><div class="slotph__box">' +
          '<span class="slotph__idx">' + pad(it.idx + 1) + '</span>' +
          '<span class="slotph__txt">Slot placeholder. Taruh file di folder aset lalu isi <code>src</code> pada <code>data/portfolio-data.js</code>.</span></div></div></div>';
      }

      var cap = '<div class="lb__cap"><h3 class="lb__title">' + esc(it.title) + '</h3>' +
        (it.caption ? '<p class="lb__text">' + esc(it.caption) + '</p>' : '') +
        '<div class="lb__tags">' + (it.tags || []).map(function (t) { return '<span>' + esc(t) + '</span>'; }).join('') +
        (it.date ? '<span>' + esc(it.date) + '</span>' : '') + (it.place ? '<span>' + esc(it.place) + '</span>' : '') + '</div></div>';

      stage.innerHTML = '<figure class="lb__figure"><div class="lb__frame">' + frameInner + '</div>' + cap + '</figure>';
      var fig = stage.querySelector('.lb__figure');
      requestAnimationFrame(function () { fig.classList.add('is-in'); });

      // Video controls
      if (it.kind === 'video' && it.filled) this.bindVideo();
    },
    bindVideo: function () {
      var self = this;
      var v = $('#lbVideo', this.root);
      if (!v) return;
      // Tangani kegagalan load (path salah / file hilang) tanpa melempar error.
      v.addEventListener('error', function () { toast('File video tidak ditemukan. Periksa property src pada data/portfolio-data.js.'); });
      var play = $('#vPlay'), time = $('#vTime'), seek = $('#vSeek'), rate = $('#vRate');
      function fmt(s) { s = Math.max(0, s | 0); return pad((s / 60) | 0) + ':' + pad(s % 60); }
      function upd() {
        if (!v.duration || isNaN(v.duration)) { time.textContent = '00:00 / 00:00'; return; }
        time.textContent = fmt(v.currentTime) + ' / ' + fmt(v.duration);
        seek.style.setProperty('--p', (v.currentTime / v.duration * 100) + '%');
        if (!v.paused) play.querySelector('svg').innerHTML = '<rect x="3.6" y="2.6" width="3" height="10.8" rx="1" fill="currentColor"/><rect x="9.4" y="2.6" width="3" height="10.8" rx="1" fill="currentColor"/>';
        else play.querySelector('svg').innerHTML = '<path d="M4 2.6v10.8L13 8z" fill="currentColor"/>';
      }
      v.addEventListener('timeupdate', upd);
      v.addEventListener('play', upd); v.addEventListener('pause', upd); v.addEventListener('loadedmetadata', upd);
      play.addEventListener('click', function () {
        if (v.paused) {
          // Promise play() bisa menolak (autoplay policy / file 404).
          // Tangani agar tidak menjadi unhandled rejection.
          var p = v.play();
          if (p && typeof p.catch === 'function') {
            p.catch(function (err) {
              var msg = (err && err.name === 'NotAllowedError')
                ? 'Browser memblokir playback. Klik sekali lagi untuk memutar.'
                : 'Video tidak dapat diputar. Periksa path file di data/portfolio-data.js.';
              if (self.root && !self.root.hidden) toast(msg);
            });
          }
        } else {
          v.pause();
        }
      });
      seek.addEventListener('input', function () { if (v.duration) v.currentTime = v.duration * (seek.value / 100); });
      var rates = [1, 1.25, 1.5, 2, .75];
      rate.addEventListener('click', function () {
        var i = (rates.indexOf(v.playbackRate) + 1) % rates.length;
        v.playbackRate = rates[i]; rate.textContent = rates[i] + 'x';
      });
      // Pause video saat lightbox ditutup / ganti item
      this._cleanup = function () { try { v.pause(); } catch (e) {} };
    },
    step: function (d) {
      if (!this.current.length) return;
      if (this._cleanup) { this._cleanup(); this._cleanup = null; }
      this.pos = (this.pos + d + this.current.length) % this.current.length;
      this.render();
    },
    close: function () {
      if (!this.root) return;
      var self = this;
      if (this._cleanup) { this._cleanup(); this._cleanup = null; }
      this.root.classList.remove('is-open');
      document.body.style.overflow = '';
      setTimeout(function () { self.root.hidden = true; }, 460);
      if (this.lastFocus && this.lastFocus.focus) this.lastFocus.focus();
    }
  };
  window.Lightbox = Lightbox;

  // Esc global
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && Lightbox.root && !Lightbox.root.hidden) Lightbox.close();
  });

  /* ------------------------------------------------------- 14. HERO IMG fallback */
  function heroFallback() {
    var im = $('#heroPhoto'); if (!im) return;
    im.addEventListener('error', function () {
      im.classList.add('is-missing');
      im.removeAttribute('src');
      im.setAttribute('alt', (D.profile ? D.profile.name : 'Profil') + ' — foto belum diisi');
    });
    if (im.complete && im.naturalWidth === 0 && im.getAttribute('src')) im.dispatchEvent(new Event('error'));
  }

  /* --------------------------------------------------------------- BOOTSTRAP */
  function init() {
    bindData();
    heroFallback();
    ambient();
    clock();
    calendar();
    reveal();
    tilt();
    wheel();
    preview();
    dashboard();
    topbar();
    Sound.init();
    window.Lightbox = Lightbox;
    document.documentElement.classList.add('is-ready');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();
