/* ==========================================================================
   gallery-foto.js — LOGIC GALERI FOTO
   Masonry grid 60 slot, filter kategori, pencarian, lazy loading, lightbox.
   ========================================================================== */
(function () {
  'use strict';

  var D = window.PORTFOLIO_DATA || {};
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  };
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  var grid = $('#grid');
  if (!grid) return;

  var all = (window.__MEDIA && window.__MEDIA.photos) || [];
  var active = 'semua';
  var query = '';

  /* ------------------------------------------------------------ STATS */
  function renderStats() {
    var filled = all.filter(function (x) { return x.filled; }).length;
    var tags = {};
    all.forEach(function (x) { (x.tags || []).forEach(function (t) { if (t !== 'kosong') tags[t] = 1; }); });
    var map = { statTotal: all.length, statFilled: filled, statEmpty: all.length - filled, statTags: Object.keys(tags).length };
    Object.keys(map).forEach(function (k) { var el = $('#' + k); if (el) el.textContent = map[k]; });
  }

  /* ---------------------------------------------------------- FILTERS */
  function allTags() {
    var t = [];
    all.forEach(function (x) { (x.tags || []).forEach(function (v) { if (v !== 'kosong' && t.indexOf(v) < 0) t.push(v); }); });
    return t.sort();
  }

  function renderFilters() {
    var host = $('#filters'); if (!host) return;
    var tags = allTags();
    var html = '<button type="button" class="chip is-active" data-tag="semua">Semua <small>' + all.length + '</small></button>';
    tags.forEach(function (t) {
      var n = all.filter(function (x) { return (x.tags || []).indexOf(t) >= 0; }).length;
      html += '<button type="button" class="chip" data-tag="' + esc(t) + '">' + esc(t) + ' <small>' + n + '</small></button>';
    });
    host.innerHTML = html;
    host.addEventListener('click', function (e) {
      var b = e.target.closest('.chip'); if (!b) return;
      $$('.chip', host).forEach(function (c) { c.classList.remove('is-active'); });
      b.classList.add('is-active');
      active = b.getAttribute('data-tag');
      renderGrid();
    });
  }

  /* ------------------------------------------------------------ GRID */
  function matches(x) {
    if (active !== 'semua' && (x.tags || []).indexOf(active) < 0) return false;
    if (!query) return true;
    var hay = (x.title + ' ' + x.caption + ' ' + (x.tags || []).join(' ') + ' ' + x.date + ' ' + x.place).toLowerCase();
    return hay.indexOf(query) >= 0;
  }

  function cardHTML(x) {
    var media = x.filled
      ? '<img src="' + esc(x.src) + '" alt="' + esc(x.title) + '" loading="lazy" decoding="async" width="800" height="1000">'
      : '<div class="slotph"><div class="slotph__box"><span class="slotph__idx">' + pad(x.idx + 1) +
        '</span><span class="slotph__txt">Slot foto kosong</span></div></div>';

    return '<article class="mitem' + (x.filled ? '' : ' is-empty') + '" data-i="' + x.idx + '" tabindex="0" role="button" aria-label="Buka ' + esc(x.title) + '">' +
      '<figure class="mitem__frame">' + media +
      '<span class="mitem__idx">' + pad(x.idx + 1) + '</span>' +
      (x.date ? '<span class="mitem__date">' + esc(x.date) + '</span>' : '') +
      '<span class="mitem__zoom" aria-hidden="true"><svg viewBox="0 0 20 20"><circle cx="8.6" cy="8.6" r="5.4" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M12.6 12.6L17 17M8.6 6.4v4.4M6.4 8.6h4.4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg></span>' +
      '</figure>' +
      '<div class="mitem__meta">' +
      '<h3 class="mitem__title">' + esc(x.title) + '</h3>' +
      (x.caption ? '<p class="mitem__cap">' + esc(x.caption) + '</p>' : '') +
      '<div class="mitem__tags">' + (x.tags || []).filter(function (t) { return t !== 'kosong'; })
        .map(function (t) { return '<span>' + esc(t) + '</span>'; }).join('') +
      (x.place ? '<span class="mitem__place">' + esc(x.place) + '</span>' : '') + '</div>' +
      '</div></article>';
  }

  function renderGrid() {
    var list = all.filter(matches);
    grid.innerHTML = list.map(cardHTML).join('');
    var empty = $('#emptyState');
    if (empty) empty.hidden = list.length > 0;
    observeCards();
  }

  /* ------------------------------------------------- LAZY LOAD IMG */
  function observeCards() {
    $$('img[loading="lazy"]', grid).forEach(function (im) {
      // lazy attribute sudah cukup untuk browser modern; ini fallback eager check
      if (im.complete) return;
    });
    if (!('IntersectionObserver' in window)) return;
    var io = new IntersectionObserver(function (en) {
      en.forEach(function (x) {
        if (!x.isIntersecting) return;
        var fig = x.target;
        fig.classList.add('is-loaded');
        io.unobserve(fig);
      });
    }, { rootMargin: '200px' });
    $$('.mitem__frame', grid).forEach(function (f) { io.observe(f); });
  }

  /* ---------------------------------------------------------- EVENTS */
  grid.addEventListener('click', function (e) {
    var c = e.target.closest('.mitem'); if (!c) return;
    openAt(+c.getAttribute('data-i'));
  });
  grid.addEventListener('keydown', function (e) {
    var c = e.target.closest('.mitem'); if (!c) return;
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openAt(+c.getAttribute('data-i')); }
  });

  function openAt(idx) {
    var list = all.filter(matches);
    var pos = 0;
    for (var i = 0; i < list.length; i++) if (list[i].idx === idx) { pos = i; break; }
    // Lightbox dibangun ulang dengan daftar terfilter
    if (window.Lightbox) {
      window.Lightbox.open(list, pos, 'foto');
    }
  }

  var search = $('#searchInput');
  if (search) {
    var tmr = null;
    search.addEventListener('input', function () {
      clearTimeout(tmr);
      tmr = setTimeout(function () {
        query = search.value.trim().toLowerCase();
        renderGrid();
      }, 180);
    });
  }

  var hint = $('#fillHint');
  if (hint) {
    hint.addEventListener('click', function () {
      if (window.Lightbox) {
        window.Lightbox.open([{
          kind: 'foto', idx: 0, filled: false,
          title: 'Cara mengisi slot foto',
          caption: '1) Taruh file .jpg / .png / .webp di folder assets/images/photos/. ' +
                   '2) Buka data/portfolio-data.js pada bagian photos.items. ' +
                   '3) Isi property src (contoh: assets/images/photos/foto-01.jpg), lalu isi title, caption, tags, dan date. ' +
                   '4) Simpan, refresh browser. Slot yang belum diisi tetap tampil sebagai frame placeholder, tidak error.',
          tags: ['panduan', 'offline-first']
        }], 0, 'foto');
      }
    });
  }

  /* ------------------------------------------------------------ BOOT */
  renderStats();
  renderFilters();
  renderGrid();
})();
